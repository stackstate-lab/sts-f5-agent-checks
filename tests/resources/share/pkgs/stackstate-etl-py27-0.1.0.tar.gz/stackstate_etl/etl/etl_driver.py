
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import json
import logging
import os
try:
    import pathlib
except ImportError:
    import pathlib2 as pathlib
from logging import Logger
from typing import Any, Dict, List
import yaml
from importlib_resources import files
from stackstate_etl.etl.interpreter import ComponentTemplateInterpreter, DataSourceInterpreter, EventTemplateInterpreter, HeathTemplateInterpreter, MetricTemplateInterpreter, ProcessorInterpreter, QueryInterpreter, QueryProcessorInterpreter, TopologyContext
from stackstate_etl.model.etl import ETL, ComponentTemplate, EventTemplate, HealthTemplate, MetricTemplate, Query
from stackstate_etl.model.factory import TopologyFactory
from stackstate_etl.model.instance import InstanceInfo


class TemplateLookup(object):

    def __init__(self):
        self.log = logging.getLogger()
        self.component = {

        }
        self.event = {

        }
        self.metric = {

        }
        self.health = {

        }

    def index(self, etl):

        def add(attr_name, key, value):
            item = getattr(self, attr_name)
            if (key in item):
                logging.error(u''.join([u'{}'.format(attr_name), u" template '", u'{}'.format(
                    key), u"' already defined [", u'{}'.format(etl.source), u']. Template names must be unique. Ignoring...']))
            else:
                item[key] = value

        def add_all(attr_name, items):
            for item in items:
                add(attr_name, item.name, item)
        if (etl.template is not None):
            add_all(u'component', etl.template.components)
            add_all(u'event', etl.template.events)
            add_all(u'metric', etl.template.metrics)
            add_all(u'health', etl.template.health)


class ETLDriver(object):

    def __init__(self, conf, factory, log):
        self.log = log
        self.factory = factory
        self.factory.log = log
        self.conf = conf
        conf.etl.source = u'conf.yaml'
        self.models = self._init_model(conf.etl)
        self.template_lookup = self._init_template_lookup()

    def process(self):
        global_datasources = {

        }
        global_session = {

        }
        for model in self.models:
            processor = ETLProcessor(
                model, self.template_lookup, self.conf, self.factory, self.log)
            ctx = TopologyContext(
                factory=self.factory, datasources=global_datasources, global_session=global_session)
            processor.process(ctx)
        unmerged_components = [
            c.uid for c in self.factory.components.values() if c.mergeable]
        if (len(unmerged_components) > 0):
            raise Exception(u''.join(
                [u'Unmerged components not allowed in factory at final processing stage. $', u'{}'.format(unmerged_components)]))

    def _init_template_lookup(self):
        lookup = TemplateLookup()
        for model in self.models:
            self.log.info(
                u''.join([u'Loading templates from ', u'{}'.format(model.source), u'.']))
            lookup.index(model)
        return lookup

    def _init_model(self, model):
        model_list = []
        for etl_ref in model.refs:
            model_list.extend(self._load_ref(etl_ref))
        model_list.append(model)
        return model_list

    def _load_ref(self, etl_ref):
        if etl_ref.startswith(u'module_dir://'):
            yaml_files = sorted(files(etl_ref[13:]).glob(u'*.yaml'))
        elif etl_ref.startswith(u'module_file://'):
            yaml_files = [files(etl_ref[14:])]
        elif etl_ref.startswith(u'file://'):
            file_name = etl_ref[7:]
            if os.path.isfile(file_name):
                yaml_files = [file_name]
            else:
                yaml_files = sorted(pathlib.Path(file_name).glob(u'*.yaml'))
        else:
            raise Exception(u''.join([u"ETL ref '", u'{}'.format(
                etl_ref), u"' not supported. Must be one of 'module_dir://', 'module_file://','file://'"]))
        results = []
        for yaml_file in yaml_files:
            with open(unicode(yaml_file)) as f:
                etl_data = yaml.load(f)
            etl_model = ETL(etl_data[u'etl'])
            etl_model.source = unicode(yaml_file)
            etl_model.validate()
            results.extend(self._init_model(etl_model))
        return results


class ETLProcessor(object):

    def __init__(self, etl, template_lookup, conf, factory, log):
        self.template_lookup = template_lookup
        self.factory = factory
        self.log = log
        self.conf = conf
        self.etl = etl
        self.query_specs = {

        }

    def process(self, ctx):
        self._process_pre_processors(ctx)
        self._process_queries(ctx)
        self._process_post_processors(ctx)

    def _process_queries(self, ctx):
        counters = {

        }
        self._init_datasources(ctx)
        query_post_processor = QueryProcessorInterpreter(ctx)
        for query_spec in self.etl.queries:
            query_results = self._get_query_result(ctx, query_spec)
            if ((query_results is None) or (len(query_results) == 0)):
                self.log.warning(u''.join([u'Query ', u'{}'.format(
                    query_spec.name), u' returned no results! Check query logic in template.']))
            counters[u''.join([u'Query_`', u'{}'.format(
                query_spec.name), u'`_Items'])] = len(query_results)
            processed_by_counter = 0
            for template_ref in query_spec.template_refs:
                interpreter = self._get_interpreter(ctx, template_ref)
                for item in query_results:
                    if interpreter.active(item):
                        try:
                            interpreter.interpret(item)
                            processed_by_counter += 1
                        except Exception as e:
                            self.log.error(json.dumps(item, indent=4))
                            raise e
            for item in query_results:
                ctx.item = item
                query_post_processor.interpret(query_spec)
            if (processed_by_counter == 0):
                self.log.warning(u''.join(
                    [u'Unprocessed Count for Query ', u'{}'.format(query_spec.name), u' is 0']))
        self.log.info(
            u''.join([u'Query Template Processing Counters:\n', u'{}'.format(counters)]))

    def _get_interpreter(self, ctx, template_ref):
        template = self.template_lookup.component.get(template_ref, None)
        if template:
            return ComponentTemplateInterpreter(ctx, template, self.conf.domain, self.conf.layer, self.conf.environment)
        template = self.template_lookup.event.get(template_ref, None)
        if template:
            return EventTemplateInterpreter(ctx, template, self.conf.domain, self.conf.layer, self.conf.environment)
        template = self.template_lookup.metric.get(template_ref, None)
        if template:
            return MetricTemplateInterpreter(ctx, template, self.conf.domain, self.conf.layer, self.conf.environment)
        template = self.template_lookup.health.get(template_ref, None)
        if template:
            return HeathTemplateInterpreter(ctx, template, self.conf.domain, self.conf.layer, self.conf.environment)
        raise Exception(
            u''.join([u"Template '", u'{}'.format(template_ref), u"' not found."]))

    def _process_post_processors(self, ctx):
        for processor_spec in self.etl.post_processors:
            ProcessorInterpreter(ctx).interpret(processor_spec)

    def _process_pre_processors(self, ctx):
        for processor_spec in self.etl.pre_processors:
            ProcessorInterpreter(ctx).interpret(processor_spec)

    def _init_datasources(self, ctx):
        interpreter = DataSourceInterpreter(ctx)
        for ds in self.etl.datasources:
            if (ds.name not in ctx.datasources):
                interpreter.interpret(ds, self.conf)

    @staticmethod
    def _get_query_result(ctx, query):
        interpreter = QueryInterpreter(ctx)
        return interpreter.interpret(query)
